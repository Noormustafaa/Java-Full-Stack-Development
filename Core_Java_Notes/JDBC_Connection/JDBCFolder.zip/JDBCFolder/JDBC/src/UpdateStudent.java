import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateStudent {
    public static void main(String[] args) {
        String jdbcURL = "jdbc:mysql://localhost:3306/testdb";
        String username = "root";
        String password = "0000"; // 🔁 Replace with your MySQL password

        try {
            // Connect to database
            Connection connection = DriverManager.getConnection(jdbcURL, username, password);

            // SQL UPDATE query
            String sql = "UPDATE students SET name = ?, email = ? WHERE id = ?";

            // Prepare statement
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, "NoorM" );             // New name
            statement.setString(2, "habib.com");     // New email
            statement.setInt(3, 1);                         // ID of student to update

            // Execute update
            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("✅ Student updated successfully!");
            } else {
                System.out.println("⚠ No student found with that ID.");
            }

            // Close connection
            connection.close();
        } catch (SQLException e) {
            System.out.println("❌ Error updating student.");
            e.printStackTrace();
        }
    }
}
