import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class insert_Data {
    public static void main(String[] args) {
        String jdbcURL = "jdbc:mysql://localhost:3306/testdb";
        String username = "root";
        String password = "0000"; // 🔁 Replace with your MySQL password

        try {
            // Connect to database
            Connection connection = DriverManager.getConnection(jdbcURL, username, password);

            // SQL INSERT query
            String sql = "INSERT INTO students (name, email) VALUES (?, ?)";

            // Prepare statement
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, "Noor Mustafa");         // name value
            statement.setString(2, "noormustafa@gmail.com"); // email value

            // Execute insert
            int rowsInserted = statement.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("✅ A new student was inserted successfully!");
            }

            // Close connection
            connection.close();
        } catch (SQLException e) {
            System.out.println("❌ Error inserting data.");
            e.printStackTrace();
        }
    }
}
