import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCConnection {
    public static void main(String[] args) {
        // Change these values to your actual database info
        String jdbcURL = "jdbc:mysql://localhost:3306/testdb"; // replace testdb with your DB name
        String username = "root";
        String password = "0000"; // replace with your MySQL password

        try {
            // Connect to MySQL database
            Connection connection = DriverManager.getConnection(jdbcURL, username, password);
            System.out.println("✅ Connection successful!");

            // Close connection
            connection.close();
        } catch (SQLException e) {
            System.out.println("❌ Connection failed!");
            e.printStackTrace();
        }
    }
}
