import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DleteStudent {
    public static void main(String[] args) {
        String jdbcURL = "jdbc:mysql://localhost:3306/testdb";
        String username = "root";
        String password = "0000"; // 🔁 Replace with your MySQL password

        try {
            // Connect to database
            Connection connection = DriverManager.getConnection(jdbcURL, username, password);

            // SQL DELETE query
            String sql = "DELETE FROM students WHERE id = ?";

            // Prepare statement
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, 1); // Replace with the student ID to delete

            // Execute delete
            int rowsDeleted = statement.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("✅ Student deleted successfully!");
            } else {
                System.out.println("⚠ No student found with that ID.");
            }

            // Close connection
            connection.close();
        } catch (SQLException e) {
            System.out.println("❌ Error deleting student.");
            e.printStackTrace();
        }
    }
}
