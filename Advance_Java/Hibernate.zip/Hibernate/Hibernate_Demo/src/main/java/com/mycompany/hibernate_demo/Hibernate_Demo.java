package com.mycompany.hibernate_demo;

import com.mycompany.hibernate_demo.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Hibernate_Demo {

    public static void main(String[] args) {

        // ✅ Step 1: Hibernate configure karo aur SessionFactory banao
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml") // config file
                .addAnnotatedClass(User.class) // tumhari entity class
                .buildSessionFactory();

        // ✅ Step 2: Hibernate session open karo
        Session session = factory.openSession();

        try {
            // ✅ Step 3: Ek naya user object banao
//            User user = new User(1, "Ali", "ali@example.com");
            User user1 =new User(2,"Noor","noormustafa@gmail.com");
            // ✅ Step 4: Transaction start karo
            session.beginTransaction();

            // ✅ Step 5: User object ko save karo
//            session.save(user);
            session.save(user1);

            // ✅ Step 6: Commit transaction
            session.getTransaction().commit();

            System.out.println(" User saved successfully!");

        } finally {
            session.close();
            factory.close();
        }
    }
}
